package com.example.bookbearer.modmail;

public interface ModMailMod {

    void reAutenticateAndChangeMail(String uMail,String uPass);

}
