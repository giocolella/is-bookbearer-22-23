package com.example.bookbearer.addreview;

import com.example.bookbearer.beans.Review;

public interface AddReviewMod {

    void addReview(String ISBN,Review review);

}
