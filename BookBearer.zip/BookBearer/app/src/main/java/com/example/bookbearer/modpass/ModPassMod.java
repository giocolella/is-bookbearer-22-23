package com.example.bookbearer.modpass;

public interface ModPassMod {

    void reAutenticateAndChangePass(String uNPass,String uOPass);

}
