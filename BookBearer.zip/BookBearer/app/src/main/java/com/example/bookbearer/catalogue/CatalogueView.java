package com.example.bookbearer.catalogue;

public interface CatalogueView {

    void catalogueMessage(String msg);
    void bookAdded();

}
