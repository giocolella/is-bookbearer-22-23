package com.example.bookbearer.catalogue;

import com.example.bookbearer.beans.Books;

public interface CatalogueMod {

    void addCatalogueBook(Books book);

}
