package com.example.bookbearer.registration;

public interface RegView {

    void regMessage(String msg);
    void goToLogin();

}
