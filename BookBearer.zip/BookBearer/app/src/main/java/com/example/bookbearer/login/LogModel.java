package com.example.bookbearer.login;

public interface LogModel {

    void loginUser(String uMail,String uPass);
    void checkList(String userId);
    void isCataloghist(String uMail,String uPass);

}
