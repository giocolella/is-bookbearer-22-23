package com.example.bookbearer.modpass;

public interface ModPassView {

    void modMessage(String msg);
    void finishActivity();

}
