package com.example.bookbearer.login;

public interface LogView {

    void regMessage(String msg);
    void StartActivity();
    void startCatalogueActivity(String uMail);

}
