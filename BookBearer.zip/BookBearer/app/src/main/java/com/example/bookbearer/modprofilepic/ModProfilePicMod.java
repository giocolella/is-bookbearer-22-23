package com.example.bookbearer.modprofilepic;

import android.net.Uri;

public interface ModProfilePicMod {

    void uploadImage(Uri imageUri);

}
