package com.example.bookbearer.registration;

public interface RegModel {

    void registerUser(String uName,String uMail, String uPass);

}
