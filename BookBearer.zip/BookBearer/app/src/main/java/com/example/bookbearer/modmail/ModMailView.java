package com.example.bookbearer.modmail;

public interface ModMailView {

    void modMessage(String msg);
    void finishActivity();

}
