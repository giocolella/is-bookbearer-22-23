package com.example.bookbearer.addreview;

public interface AddReviewView {
    void addReviewMessage(String msg);

    void reviewAdded();

}
